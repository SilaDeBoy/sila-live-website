const socket = typeof io === "function" ? io() : null;
const $ = id => document.getElementById(id);
const demoStreams = [
  { title:"Acoustic evening • songs & requests", creator:"Maya Sessions", category:"Music", viewers:"1.2K", icon:"♫", style:"music", room:"maya-sessions" },
  { title:"Real conversations, real community", creator:"The Open Table", category:"Talk", viewers:"856", icon:"◉", style:"talk", room:"open-table" },
  { title:"Late-night gaming and good vibes", creator:"Kito Plays", category:"Gaming", viewers:"2.4K", icon:"▣", style:"game", room:"kito-plays" },
  { title:"Learn something new with me", creator:"Asha Creates", category:"Learning", viewers:"439", icon:"✎", style:"learn", room:"asha-learns" },
  { title:"Sunday community check-in", creator:"Sila Community", category:"Community", viewers:"673", icon:"♡", style:"community", room:"sila-community" },
  { title:"Creative minds: share your ideas", creator:"Studio Circle", category:"Talk", viewers:"312", icon:"✦", style:"talk", room:"studio-circle" }
];
let currentView = "home", currentCategory = "All", currentRoom = "main", currentRole = "viewer";
let localStream = null, micEnabled = true, cameraEnabled = true, isLive = false, currentName = "Sila";
let peerConnections = new Map(), toastTimer, chatCleared = false, joined = false;

function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}
function setView(view) {
  currentView = view;
  document.querySelectorAll(".view").forEach(el => el.classList.toggle("active", el.id === `view-${view}`));
  document.querySelectorAll(".nav-item[data-view]").forEach(el => el.classList.toggle("active", el.dataset.view === view));
  $("sidebar").classList.remove("open");
  if (view === "studio") refreshRoomLink();
  if (view === "watch" && !joined) $("joinRoomInput").value = currentRoom;
  window.scrollTo({top:0, behavior:"smooth"});
}
document.querySelectorAll("[data-view]").forEach(el => el.addEventListener("click", () => setView(el.dataset.view)));
$("menuBtn").addEventListener("click", () => $("sidebar").classList.toggle("open"));
$("profileBtn").addEventListener("click", () => { currentName = prompt("What name should appear in live chat?", currentName) || currentName; $("profileBtn").textContent = currentName.trim().slice(0,1).toUpperCase() || "S"; toast(`Chat name set to ${currentName}`); });
function renderStreams(targetId, category="All", query="") {
  const target = $(targetId); if (!target) return;
  const list = demoStreams.filter(s => (category === "All" || s.category === category) && `${s.title} ${s.creator} ${s.category}`.toLowerCase().includes(query.toLowerCase()));
  target.innerHTML = list.length ? list.map(s => `<article class="stream-card" data-room="${s.room}" tabindex="0" role="button" aria-label="Watch ${s.title}">
    <div class="stream-thumb thumb-${s.style}"><span class="live-tag">● LIVE</span><span class="view-count">◉ ${s.viewers}</span><div class="thumb-art-icon">${s.icon}</div></div>
    <div class="stream-card-body"><h3>${escapeHtml(s.title)}</h3><div class="stream-meta"><span class="tiny-avatar">${escapeHtml(s.creator.slice(0,1))}</span><div class="meta-text"><b>${escapeHtml(s.creator)}</b><span>${escapeHtml(s.category)} · Live now</span></div><span class="category-tag">${escapeHtml(s.category)}</span></div></div>
  </article>`).join("") : `<div class="empty-state">No streams match that search. Try another category or search term.</div>`;
  target.querySelectorAll(".stream-card").forEach(card => {
    const open = () => { $("joinRoomInput").value = card.dataset.room; joinRoom(card.dataset.room); setView("watch"); };
    card.addEventListener("click", open); card.addEventListener("keydown", e => { if(e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); } });
  });
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
renderStreams("homeStreams"); renderStreams("exploreStreams");
$("categoryRow").querySelectorAll("[data-category]").forEach(btn => btn.addEventListener("click", () => {
  currentCategory = btn.dataset.category;
  $("categoryRow").querySelectorAll("[data-category]").forEach(b => b.classList.toggle("active", b === btn));
  renderStreams("exploreStreams", currentCategory, $("searchInput").value);
}));
$("searchForm").addEventListener("submit", e => { e.preventDefault(); setView("explore"); renderStreams("exploreStreams", currentCategory, $("searchInput").value); });
$("searchInput").addEventListener("input", () => { if (currentView === "explore") renderStreams("exploreStreams", currentCategory, $("searchInput").value); });
["openStudioTop","goLiveHero","goLiveBanner"].forEach(id => $(id).addEventListener("click", () => setView("studio")));
function roomUrl(room=currentRoom) { return `${location.origin}${location.pathname}#room=${encodeURIComponent(room)}`; }
function refreshRoomLink() { $("roomLink").value = roomUrl(currentRoom); }
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); toast("Link copied to clipboard"); }
  catch { const area = document.createElement("textarea"); area.value = text; document.body.appendChild(area); area.select(); document.execCommand("copy"); area.remove(); toast("Link copied"); }
}
$("copyLinkBtn").addEventListener("click", () => copyText($("roomLink").value));
$("copyRoomBtn").addEventListener("click", () => copyText(roomUrl(currentRoom)));
$("shareStudioBtn").addEventListener("click", () => copyText(roomUrl(currentRoom)));
$("shareWatchBtn").addEventListener("click", () => copyText(roomUrl(currentRoom)));
$("streamTitle").addEventListener("input", () => { if (socket && currentRole === "host") socket.emit("join-room", {roomId:currentRoom,role:"host",name:currentName,title:$("streamTitle").value}); });
function setStudioLive(live) {
  isLive = live; $("studioStatus").textContent = live ? "● LIVE" : "OFFLINE"; $("studioStatus").classList.toggle("live", live);
  $("goLiveBtn").textContent = live ? "■ End stream" : "● Go live"; $("goLiveBtn").classList.toggle("live", live);
  $("previewLive").classList.toggle("show", live);
}
async function enableCamera() {
  if (!navigator.mediaDevices?.getUserMedia) { toast("Camera access requires localhost or an HTTPS website."); return false; }
  try {
    if (!localStream) localStream = await navigator.mediaDevices.getUserMedia({video:true,audio:true});
    $("localVideo").srcObject = localStream; $("localVideo").classList.add("visible"); $("previewPlaceholder").style.display = "none";
    micEnabled = true; cameraEnabled = true; updateMediaButtons(); toast("Camera and microphone enabled"); return true;
  } catch (e) { toast(e.name === "NotAllowedError" ? "Please allow camera and microphone access." : "Could not open camera. Check that it is connected."); return false; }
}
function updateMediaButtons() {
  $("micBtn").classList.toggle("off", !micEnabled); $("cameraBtn").classList.toggle("off", !cameraEnabled);
  $("micBtn").innerHTML = `${micEnabled ? "🎙" : "🔇"} <span>${micEnabled ? "Mic on" : "Mic off"}</span>`;
  $("cameraBtn").innerHTML = `${cameraEnabled ? "▣" : "⊘"} <span>${cameraEnabled ? "Camera on" : "Camera off"}</span>`;
  if (localStream) { localStream.getAudioTracks().forEach(t => t.enabled = micEnabled); localStream.getVideoTracks().forEach(t => t.enabled = cameraEnabled); }
}
$("enableCameraBtn").addEventListener("click", enableCamera);
$("micBtn").addEventListener("click", () => { micEnabled = !micEnabled; updateMediaButtons(); });
$("cameraBtn").addEventListener("click", () => { cameraEnabled = !cameraEnabled; updateMediaButtons(); });
$("flipPreviewBtn").addEventListener("click", () => { $("localVideo").style.transform = $("localVideo").style.transform === "scaleX(-1)" ? "" : "scaleX(-1)"; toast("Preview mirror toggled"); });
function createPeer(viewerId) {
  if (!localStream || !socket || peerConnections.has(viewerId)) return;
  const pc = new RTCPeerConnection({iceServers:[{urls:"stun:stun.l.google.com:19302"}]});
  peerConnections.set(viewerId, pc);
  localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
  pc.onicecandidate = e => { if(e.candidate) socket.emit("webrtc-ice",{to:viewerId,candidate:e.candidate}); };
  pc.createOffer().then(offer => pc.setLocalDescription(offer)).then(() => socket.emit("webrtc-offer",{to:viewerId,offer:pc.localDescription})).catch(err => console.error(err));
  pc.onconnectionstatechange = () => { if(["failed","closed","disconnected"].includes(pc.connectionState)) { pc.close(); peerConnections.delete(viewerId); } };
}
async function startBroadcast() {
  if (isLive) {
    if (socket) socket.emit("stream-ended");
    peerConnections.forEach(pc => pc.close()); peerConnections.clear();
    setStudioLive(false); currentRole = "viewer";
    if (localStream) { localStream.getTracks().forEach(t => t.stop()); localStream = null; }
    $("localVideo").srcObject = null; $("localVideo").classList.remove("visible"); $("previewPlaceholder").style.display = "block";
    if(socket) socket.emit("join-room",{roomId:currentRoom,role:"viewer",name:currentName});
    toast("Stream ended"); return;
  }
  const ok = localStream ? true : await enableCamera(); if (!ok) return;
  currentRoom = currentRoom === "main" ? `sila-${Math.random().toString(36).slice(2,7)}` : currentRoom;
  currentRole = "host"; refreshRoomLink();
  if (socket) socket.emit("join-room",{roomId:currentRoom,role:"host",name:currentName,title:$("streamTitle").value});
  setStudioLive(true); $("watchTitle").textContent = $("streamTitle").value || "Sila Live stream";
  $("watchRoomLabel").textContent = `Room: ${currentRoom}`; $("joinRoomInput").value = currentRoom;
  toast("You're live! Share your room link with viewers."); setView("studio");
}
$("goLiveBtn").addEventListener("click", startBroadcast);
$("joinRoomForm").addEventListener("submit", e => { e.preventDefault(); joinRoom($("joinRoomInput").value.trim() || "main"); });
function appendChat(message) {
  const container = $("chatMessages");
  if (chatCleared) { container.innerHTML = ""; chatCleared = false; }
  const row = document.createElement("div"); row.className = "chat-msg";
  const time = new Date(message.time || Date.now()).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});
  const name = document.createElement("b"); name.textContent = message.name || "Viewer";
  const text = document.createElement("span"); text.textContent = ` ${message.text || ""}`;
  const stamp = document.createElement("small"); stamp.textContent = time;
  row.append(name,text,stamp); container.appendChild(row); container.scrollTop = container.scrollHeight;
}
function addSystem(text) { const el = document.createElement("div"); el.className = "chat-system"; el.textContent = text; $("chatMessages").appendChild(el); }
function joinRoom(roomId) {
  currentRoom = String(roomId || "main").replace(/[^a-zA-Z0-9_-]/g,"").slice(0,50) || "main";
  currentRole = "viewer"; joined = true; refreshRoomLink();
  $("watchRoomLabel").textContent = `Room: ${currentRoom}`; $("watchTitle").textContent = "Connecting to live room…";
  $("watchEmpty").style.display = "block"; $("remoteVideo").classList.remove("visible"); $("remoteVideo").srcObject = null;
  $("watchLiveBadge").classList.remove("show"); $("chatMessages").innerHTML = ""; addSystem(`Joining room ${currentRoom}…`);
  if (socket) socket.emit("join-room",{roomId:currentRoom,role:"viewer",name:currentName});
  else addSystem("Chat server unavailable. Start the Node.js server to connect.");
  if (location.hash !== `#room=${encodeURIComponent(currentRoom)}`) history.replaceState(null,"",`#room=${encodeURIComponent(currentRoom)}`);
}
$("chatForm").addEventListener("submit", e => {
  e.preventDefault(); const text = $("chatInput").value.trim(); if (!text) return;
  if(socket) socket.emit("chat-message",{text}); else appendChat({name:currentName,text,time:new Date().toISOString()});
  $("chatInput").value = "";
});
$("clearChatBtn").addEventListener("click", () => { $("chatMessages").innerHTML = ""; chatCleared = true; addSystem("Chat view cleared on your screen."); });
$("followBtn").addEventListener("click", () => { const b = $("followBtn"); b.classList.toggle("following"); b.textContent = b.classList.contains("following") ? "✓ Following" : "＋ Follow"; toast(b.classList.contains("following") ? "You're following this creator" : "Unfollowed creator"); });
if (socket) {
  socket.on("room-state", state => {
    if (state.roomId !== currentRoom) return;
    $("watchViewers").textContent = state.viewers || 0; $("studioViewers").textContent = state.viewers || 0;
    $("watchTitle").textContent = state.title || "Sila Live stream";
    $("watchCreator").textContent = state.live ? "Sila Live Creator" : "Room creator";
    if (state.live) { $("watchEmpty").style.display = "none"; $("watchLiveBadge").classList.add("show"); }
    else { $("watchEmpty").style.display = "block"; $("watchLiveBadge").classList.remove("show"); $("watchTitle").textContent = "Waiting for the creator…"; }
    (state.messages || []).forEach(appendChat);
    if (currentRole === "host" && state.hostId && state.hostId !== socket.id) toast("Another creator is using this room.");
  });
  socket.on("room-stats", state => {
    if (state.roomId !== currentRoom) return;
    $("watchViewers").textContent = state.viewers || 0; $("studioViewers").textContent = state.viewers || 0;
    if (state.live) { $("watchLiveBadge").classList.add("show"); $("watchEmpty").style.display = "none"; }
    else if (currentRole !== "host") { $("watchLiveBadge").classList.remove("show"); }
  });
  socket.on("viewer-joined", ({viewerId}) => { if(currentRole === "host") createPeer(viewerId); });
  socket.on("host-ready", () => { if(currentRole !== "host") addSystem("Creator is online. Connecting to the live video…"); });
  socket.on("webrtc-offer", async ({from,offer}) => {
    try {
      const pc = new RTCPeerConnection({iceServers:[{urls:"stun:stun.l.google.com:19302"}]});
      peerConnections.set(from,pc);
      pc.ontrack = e => { $("remoteVideo").srcObject = e.streams[0]; $("remoteVideo").classList.add("visible"); $("watchEmpty").style.display = "none"; $("watchLiveBadge").classList.add("show"); };
      pc.onicecandidate = e => { if(e.candidate) socket.emit("webrtc-ice",{to:from,candidate:e.candidate}); };
      await pc.setRemoteDescription(offer); const answer = await pc.createAnswer(); await pc.setLocalDescription(answer);
      socket.emit("webrtc-answer",{to:from,answer:pc.localDescription});
    } catch(e) { console.error(e); addSystem("Could not connect to video. Try refreshing the room."); }
  });
  socket.on("webrtc-answer", async ({from,answer}) => { const pc=peerConnections.get(from); if(pc) await pc.setRemoteDescription(answer).catch(console.error); });
  socket.on("webrtc-ice", async ({from,candidate}) => { const pc=peerConnections.get(from); if(pc && candidate) await pc.addIceCandidate(candidate).catch(()=>{}); });
  socket.on("chat-message", appendChat);
  socket.on("stream-ended", () => {
    $("remoteVideo").srcObject = null; $("remoteVideo").classList.remove("visible"); $("watchEmpty").style.display = "block"; $("watchLiveBadge").classList.remove("show");
    $("watchTitle").textContent = "This stream has ended"; addSystem("The creator ended the stream.");
  });
  socket.on("connect", () => $("chatOnline").textContent = "Connected to room");
  socket.on("disconnect", () => $("chatOnline").textContent = "Reconnecting…");
}
function init() {
  const match = location.hash.match(/room=([^&]+)/);
  if (match) { const room = decodeURIComponent(match[1]); $("joinRoomInput").value = room; joinRoom(room); setView("watch"); }
  else { currentRoom = "main"; refreshRoomLink(); }
}
init();
